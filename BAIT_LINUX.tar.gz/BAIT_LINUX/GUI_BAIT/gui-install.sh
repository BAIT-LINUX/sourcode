cd
clear
echo "\033[5;31m"
echo ""
echo "             █░▄▀ █▀▀█ █▀▀▄ █▀▀▀   █▀▀█ █▀▀█ ▀█▀ ▀▀█▀▀        "
echo "             █▀▄░ █▄▄█ █░░█ █░▀█   █▀▀▄ █▄▄█ ░█░ ░▒█░░        "
echo "             █░▒█ ▀░░▀ ▀░░▀ ▀▀▀▀   █▄▄█ ▀░░▀ ▄█▄ ░▒█░░        "
printf '\033[1;33m'
echo "  ─────────────╔╗─╔╗──────────  ───╔═╗──────  ╔╗────╔╗──────╔═╗─────────"""
echo "  ╔═╗╔╦╗╔═╗─╔═╗║╚╗╠╣╔═╗╔═╗─╔╗─  ╔╦╗║═╣╔═╗╔╦╗  ╠╣╔═╦╗║╚╗╔═╗╔╦╗║═╣╔═╗─╔═╗╔═╗"""
echo "  ║╬║║╔╝║╬╚╗║╬║║║║║║║═╣║╬╚╗║╚╗  ║║║╠═║║╩╣║╔╝  ║║║║║║║╔╣║╩╣║╔╝║╔╝║╬╚╗║═╣║╩╣"""
echo "  ╠╗║╚╝─╚══╝║╔╝╚╩╝╚╝╚═╝╚══╝╚═╝  ╚═╝╚═╝╚═╝╚╝─  ╚╝╚╩═╝╚═╝╚═╝╚╝─╚╝─╚══╝╚═╝╚═╝"""
echo "  ╚═╝───────╚╝────────────────  ────────────  ────────────────────────────"""
echo "\033[5;32m"
echo ""
echo ""
echo ""
echo ""
read -p "[+] Do you want to continue? [Y/n]" it
case $it in
y)
pkg install x11-repo -y
pkg install tigervnc -y
pkg install fluxbox -y
pkg instal openbox pypanel xorg-xsetroot -y
pkg install xfce4-terminal -y
pkg install xfce4 -y
pkg install xorg-xsetroot -y
pkg install xterm -y
pkg install xcompmgr -y
pkg install xfce4-settings -y
pkg install polybar libnl -y
pkg install st -y
pkg install geany -y
pkg install thunar -y
pkg install pcmanfm -y
kg install rofi -y
pkg install feh -y
pkg install neofetch -y
pkg install netsurt -y
pkg install git -y
pkg install wget -y
pkg install curl -y
pkg install zsh -y
pkg install vim -y
pkg install htop -y
pkg install elinks -y
pkg install mutt -y
pkg install mc -y
pkg install ranger -y
pkg install cmus -y
pkg install cava -y
pkg install pulseaudio -y
pkg install netsurf
clear ;;
n)exit ;;
*)exit ;;
esac

read -p "[+] Are you going to install additional software? [Y/n]" at
case $at in
y)cd /data/data/com.termux/files/usr/bin/
sh GUI-tools.sh ;;
n)gui-start ;;
*)exit ;;
esac
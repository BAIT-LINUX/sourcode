cd
clear
echo "\033[5;31m" 
echo "" 
echo "             █░▄▀ █▀▀█ █▀▀▄ █▀▀▀   █▀▀█ █▀▀█ ▀█▀ ▀▀█▀▀        " 
echo "             █▀▄░ █▄▄█ █░░█ █░▀█   █▀▀▄ █▄▄█ ░█░ ░▒█░░        " 
echo "             █░▒█ ▀░░▀ ▀░░▀ ▀▀▀▀   █▄▄█ ▀░░▀ ▄█▄ ░▒█░░        " 
printf '\033[1;33m' 
echo "  ─────────────╔╗─╔╗──────────  ───╔═╗──────  ╔╗────╔╗──────╔═╗─────────"""
echo "  ╔═╗╔╦╗╔═╗─╔═╗║╚╗╠╣╔═╗╔═╗─╔╗─  ╔╦╗║═╣╔═╗╔╦╗  ╠╣╔═╦╗║╚╗╔═╗╔╦╗║═╣╔═╗─╔═╗╔═╗"""
echo "  ║╬║║╔╝║╬╚╗║╬║║║║║║║═╣║╬╚╗║╚╗  ║║║╠═║║╩╣║╔╝  ║║║║║║║╔╣║╩╣║╔╝║╔╝║╬╚╗║═╣║╩╣"""
echo "  ╠╗║╚╝─╚══╝║╔╝╚╩╝╚╝╚═╝╚══╝╚═╝  ╚═╝╚═╝╚═╝╚╝─  ╚╝╚╩═╝╚═╝╚═╝╚╝─╚╝─╚══╝╚═╝╚═╝"""
echo "  ╚═╝───────╚╝────────────────  ────────────  ────────────────────────────"""
echo ""
echo ""
echo ""
echo "\033[5;32m"
echo ""
echo ""
echo ""
echo ""
read -p "[+] Do you want to continue? [Y/n]" it
case $it in
y)
pkg unistall tigervnc -y
pkg unistall x11-repo -y
pkg unistall fluxbox -y
pkg unistall openbox obconf -y
pkg unistall xfce4 -y
pkg unistall xorg-xsetroot -y
pkg unistall xterm -y
pkg unistall xcompmgr -y
pkg unistall xfce4-settings -y
pkg unistall polybar libnl -y
pkg unistall st -y
pkg unistall geany -y
pkg unistall thunar -y
pkg unistall pcmanfm -y
pkg unistall rofi -y
pkg unistall feh -y
pkg unistall neofetch -y
pkg unistall netsurt -y
pkg unistall git -y
pkg unistall wget -y
pkg unistall curl -y
pkg unistall zsh -y
pkg unistall vim -y
pkg unistall htop -y
pkg unistall elinks -y
pkg unistall mutt -y
pkg unistall mc -y
pkg unistall ranger -y
pkg unistall cmus -y
pkg unistall cava -y
pkg unistall pulseaudio -y
pkg unistall netsurf -y ;;
n)exit ;;
*)exit ;;
esac
clear
echo "\033[5;31m" 
echo "" 
echo "             █░▄▀ █▀▀█ █▀▀▄ █▀▀▀   █▀▀█ █▀▀█ ▀█▀ ▀▀█▀▀        " 
echo "             █▀▄░ █▄▄█ █░░█ █░▀█   █▀▀▄ █▄▄█ ░█░ ░▒█░░        " 
echo "             █░▒█ ▀░░▀ ▀░░▀ ▀▀▀▀   █▄▄█ ▀░░▀ ▄█▄ ░▒█░░        " 
printf '\033[1;33m' 
echo "  ─────────────╔╗─╔╗──────────  ───╔═╗──────  ╔╗────╔╗──────╔═╗─────────"""
echo "  ╔═╗╔╦╗╔═╗─╔═╗║╚╗╠╣╔═╗╔═╗─╔╗─  ╔╦╗║═╣╔═╗╔╦╗  ╠╣╔═╦╗║╚╗╔═╗╔╦╗║═╣╔═╗─╔═╗╔═╗"""
echo "  ║╬║║╔╝║╬╚╗║╬║║║║║║║═╣║╬╚╗║╚╗  ║║║╠═║║╩╣║╔╝  ║║║║║║║╔╣║╩╣║╔╝║╔╝║╬╚╗║═╣║╩╣"""
echo "  ╠╗║╚╝─╚══╝║╔╝╚╩╝╚╝╚═╝╚══╝╚═╝  ╚═╝╚═╝╚═╝╚╝─  ╚╝╚╩═╝╚═╝╚═╝╚╝─╚╝─╚══╝╚═╝╚═╝"""
echo "  ╚═╝───────╚╝────────────────  ────────────  ────────────────────────────"""
echo ""
echo ""
echo ""
echo ""
echo "\033[1;33mEnter (0) Quit"
echo "\033[5;32m"
read -p "Done Unistall GUI Kang BaIT: " Se
case $Se in
0) exit ;;
*) sh unistall.sh ;;
esac
#!/bin/bash
clear
echo ""
echo ""
echo "\33[1;31m      █▀▀█ █▀▀█ ▀█▀ ▀▀█▀▀\33[36;1m┏┓░┏━━┓┏━┳┓┏┳┓┏┓┏┓"
echo "\33[1;31m      █▀▀▄ █▄▄█ ░█░ ░▒█░░\33[36;1m┃┃░┗┃┃┛┃┃┃┃┃┃┃┗┓┏┛"
echo "\33[1;31m      █▄▄█ █░▒█ ▄█▄ ░▒█░░\33[36;1m┃┗┓┏┃┃┓┃┃┃┃┃┃┃┏┛┗┓"
echo "\33[32;1m      ███████████████]99%\33[36;1m┗━┛┗━━┛┗┻━┛┗━┛┗┛┗┛"
echo "\33[0m"
cd ../
cp -r BAIT_LINUX /data/data/com.termux/files/home/
cd /data/data/com.termux/files/home/storage/shared/download/
rm -rv BAIT_LINUX
cd /data/data/com.termux/files/usr/etc/
rm -rv bash.bashrc
rm -rv motd
cd
cd BAIT_LINUX
cd pluig
mv -f bash.bashrc /data/data/com.termux/files/usr/etc/
mv -f motd.sh /data/data/com.termux/files/usr/etc/
mv -f samples.sh ../
cd ../
sh samples.sh

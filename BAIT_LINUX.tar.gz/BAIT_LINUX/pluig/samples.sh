#Berkarya Sendiri Om Jangan Cuma Record
#Jangan Di Rubah Om 
#Hargai Developernya Om
#Kalo Mau Mending Berkarya Bersama Om
pkg update && pkg upgrade -y
cd /data/data/com.termux/files/usr/bin/
mkdir file
cd
cd BAIT_LINUX
pkg install git -y
pkg install ruby -y
pkg install wget -y
pkg install git -y
pkg install curl -y
pkg install python -y
pkg install php -y
pkg install make -y

cd bin
sh console.sh
chmod +x console.sh
mv -f console.sh /data/data/com.termux/files/usr/bin/file/
cd
cd BAIT_LINUX 
cd ../pluig
chmod +x update
mv update /data/data/com.termux/files/usr/bin
cd ../ 


cd
cd BAIT_LINUX

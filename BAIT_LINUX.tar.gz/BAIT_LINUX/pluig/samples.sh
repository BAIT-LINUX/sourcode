#Berkarya Sendiri Om Jangan Cuma Record
#Jangan Di Rubah Om 
#Hargai Developernya Om
#Kalo Mau Mending Berkarya Bersama Om
pkg update && pkg upgrade -y
cd /data/data/com.termux/files/usr/bin/
mkdir file
cd
cd BAIT_LINUX
pkg install git -y
pkg install ruby -y
pkg install wget -y
pkg install git -y
pkg install curl -y
pkg install python -y
pkg install php -y
pkg install make -y
read -p "[+] Do you want to continue? [Y/n]" dt
case $dt in
y)cd bin
chmod +x console.sh
cp -r console.sh /data/data/com.termux/files/usr/bin/file/
cd
cd BAIT_LINUX 
cd ../pluig
chmod +x update
mv update /data/data/com.termux/files/usr/bin
cd ../  
sh keris.sh;;
esac
read -p "[+] Are you going to install root software? [Y/n]" dh
case $dh in
y)pkg install tsu
cd bin
chmod +x console-root.sh
cp -r console-root.sh /data/data/com.termux/files/usr/bin/file/
sh console-root.sh
cd
cd BAIT_LINUX
cd ../pluig
chmod +x update
mv update /data/data/com.termux/files/usr/bin
cd ../  
sh gui.sh;;
esac
read -p "[+] Are you going to install additional software? [Y/n]" tb
case $tb in
y)cd GUI_BAIT 
mv -f gui-install /data/data/com.termux/files/usr/bin/
mv -f gui-install.sh /data/data/com.termux/files/usr/bin/
mv -f gui-start /data/data/com.termux/files/usr/bin/
mv -f gui-start.sh /data/data/com.termux/files/usr/bin/
mv -f GUI-tools.sh /data/data/com.termux/files/usr/bin/
mv -f gui-unistall /data/data/com.termux/files/usr/bin/
mv -f gui-unistall.sh /data/data/com.termux/files/usr/bin/
mv -f run-tools.sh /data/data/com.termux/files/usr/bin/
mv -f Selesai.sh /data/data/com.termux/files/usr/bin/
cd /data/data/com.termux/files/usr/bin/
chmod +x gui-install
chmod +x gui-install.sh
chmod +x gui-start
chmod +x gui-start.sh
chmod +x GUI-tools.sh
chmod +x gui-unistall
chmod +x gui-unistall.sh
chmod +x run-tools.sh
chmod +x Selesai.sh
cd BAIT_LINUX 
cd ../pluig
mv update /data/data/com.termux/files/usr/bin
cd /data/data/com.termux/files/usr/bin/
chmod +x update
cd
cd BAIT_LINUX ;;
esac
mv samples.sh pluig
clear
cd
rm -rv BAIT-LINUX
rm -rv sourcode
echo ""
echo ""
echo "    \33[32;1mDone..../restart your terminal"
exit
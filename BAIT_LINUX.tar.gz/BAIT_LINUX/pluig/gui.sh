cd GUI_BAIT 
chmod +x gui-install
chmod +x gui-install.sh
chmod +x gui-start
chmod +x gui-start.sh
chmod +x GUI-tools.sh
chmod +x gui-unistall
chmod +x gui-unistall.sh
chmod +x run-tools.sh
chmod +x Selesai.sh
mv -f gui-install /data/data/com.termux/files/usr/bin/
mv -f gui-install.sh /data/data/com.termux/files/usr/bin/
mv -f gui-start /data/data/com.termux/files/usr/bin/
mv -f gui-start.sh /data/data/com.termux/files/usr/bin/
mv -f GUI-tools.sh /data/data/com.termux/files/usr/bin/
mv -f gui-unistall /data/data/com.termux/files/usr/bin/
mv -f gui-unistall.sh /data/data/com.termux/files/usr/bin/
mv -f run-tools.sh /data/data/com.termux/files/usr/bin/
mv -f Selesai.sh /data/data/com.termux/files/usr/bin/
cd ../pluig
mv update /data/data/com.termux/files/usr/bin
cd /data/data/com.termux/files/usr/bin/
chmod +x update

read -p "[+] Are you going to install root software? [Y/n]" dh
case $dh in
y)cd bin
sh console-root.sh
chmod +x console-root.sh
mv -f console-root.sh /data/data/com.termux/files/usr/bin/file/
cd
cd BAIT_LINUX
cd ../pluig
chmod +x update
mv update /data/data/com.termux/files/usr/bin
cd ../ 
pkg install tsu;;
esac

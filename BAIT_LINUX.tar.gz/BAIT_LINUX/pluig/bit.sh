clear
echo ""
echo ""
echo "    \33[31;1m    restart your terminal"